Thanks for downloading this theme!

Theme Name: OnePage
Theme URL: https://bootstrapmade.com/onepage-multipurpose-bootstrap-template/
Author: BootstrapMade
Author URL: https://bootstrapmade.com